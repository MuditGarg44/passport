import React, { Component } from 'react';
import "./css/style.css"
import NewUser from "./components/NewUser/NewUser"
import Login from "./components/Login/Login";
import Dashboard from "./components/Dashboard/Dashboard"
import {
  BrowserRouter as Router,
  Route
} from "react-router-dom";


class App extends Component{
  render() {
    return (
       <div className="App">

        <Router>
          <Route 
            exact
            path="/"
            render={()=><NewUser/>}
          />

          <Route
            path="/login"
            render={()=><Login/>}
          />

          <Route
            path="/dashboard"
            render={(props)=><Dashboard {...props}/>}
          />
        </Router>
         
      
       </div>
    );
  }
}

export default App;
