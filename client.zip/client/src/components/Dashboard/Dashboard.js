import React, { Component } from 'react';
import "../../css/style.css"
import axios from "axios";

export default class Dashboard extends Component{
    constructor(props)
    {
        super(props)
        console.log(this.props)
    }
    componentDidMount()
    {
        axios.get("http://localhost:9000/dashboard")
        .then(res=> {   
            if(!res.data.isAuth)
            {
                console.log(res.data.isAuth);
                this.props.history.push("/login");
            }
        })
        .catch(err=>{
            console.log(err.data);
        })
    }
    render() {
        return (
             <div> This should run only after authentication</div>
        );
    }
}