import React, { Component } from 'react';
import "../../css/style.css"
import axios from "axios"

class Login extends Component
{
    constructor(props)
    {
        super(props);
        this.state =
        {
            username:"",
            password:""
        }
    }
    handleChange = event =>
    {
        this.setState({
            [event.target.name]: event.target.value
        });
        // console.log(this.state.username + " " + event.target.value );
    };

    //  handleSubmit = (event,data) =>
    // {
    //   event.preventDefault();
    //   axios.post("http://localhost:9000/login", data)
    //   .then(res=>{
    //     console.log(res.data.message);
    //   })
    //   .catch(error=>{
    //     console.log(error.response.data.message);  
    //   })
    // }
    handleSubmit = async(event,data) =>
    {
        event.preventDefault();
        try
        {
            const res = await axios.post("http://localhost:9000/login", data);
            document.getElementById("messageP").innerHTML = res.data.message;

            // console.log(res.data);
            // setTimeout((()=>this.props.history.push("/home")),1500);
        }
        catch(error)
        {
            document.getElementById("messageP").innerHTML = error.response.data;
            // console.log(error.response.data)
        }
        
    }
  
    
    render() {

        return (
            <section className="loginsection">
            <form method="post" onSubmit={event=> this.handleSubmit(event,this.state)}>
                 <div>
                    <input type="text" name="username" value={this.state.username} className="usertxt" placeholder="Username" onChange={this.handleChange}/>
                 </div>
                 <div>
                    <input type="password" name="password" value={this.state.password} className="passtxt" placeholder="Password" onChange={this.handleChange} />

                 </div>
                 <div>
                    <input type="submit" value="Login" className="loginbtn"/>
                 </div>
                 <p id="messageP"></p>
            </form>
            </section>
        );
    }
}
export default Login;  