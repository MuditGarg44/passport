import React, { Component } from 'react';
import "../../css/style.css"
import Axios from "axios";

export default class NewUser extends Component{
    constructor(props)
    {
        super(props)
        this.state = {
            username: "",
            passowrd:""
        };
    }

    handleChange = (event) =>
    {
        this.setState({
            [event.target.name] : event.target.value
        })
    }
    handleSubmit = (event,data) =>
  {
    event.preventDefault();
    Axios.post("http://localhost:9000/adduser" , data)
    .then(response=> 
        document.getElementById("messagediv").innerHTML= response.data.message)
        .then(res=> console.log(res, " ruuuuuns"))
    .catch(err => {
        console.log(err);
        document.getElementById("messagediv").innerHTML = err.response.data;
    })
  }

    render() {
        return (
             <section className="newUserSection">
             <form onSubmit={(event)=>this.handleSubmit(event,this.state)}>
                <h1> ADD New User </h1>
                <div>
                    <input type="text" name="username" placeholder="Enter Username" value={this.state.username} onChange={this.handleChange} required/>
                </div>
                <div>
                    <input type="text" name="password" placeholder="Enter Password"  value={this.state.password} onChange={this.handleChange} required/>
                </div>

                <div id="messagediv">

                </div>
                <div>
                    <input type="submit" value="Submit"/>
                </div>
             </form>
             </section>
        );
    }
}